# cocoagaming
## This is the datapack we use for Ancient Origins. If you don't know how to install this, you don't need it. 
https://discord.gg/jw4vce8Spm for more



Datapacks created by:


###### Nebulaa

###### Voxaire

###### User_NULL

###### Bot Cyrox

###### TheEldritchEcho

###### Mr Plague

###### Gold_Magikarp



With assistance from:


###### Apace (Creator of Origins mod)

###### Cocoa (Server owner)

###### The Origins Discord

###### Ancient Origins



Special thanks to our testers and players, including:


###### Excal Sheet

###### Diamond

###### Nossea

###### Icarus_Maru

###### thegreatseba2

###### iPxter

###### Komet

###### TrikiNya

###### Its_Kei

###### Pier

###### isak


If I missed anyone let me know! A project like this is a group effort, thanks for everything~

